<?php

	$username 	= $_GET["username"]; // username for embedded verions
	// echo $username;
	// $baseURL = "http://localhost/moodle19/";
	$baseURL = "http://ita-portal.cis.fiu.edu/";
	$certTheoryURL = "mod/quiz/view-embedded.php?id=10576&username=$username";
	// echo $baseURL . $certTheoryURL;
	$certHandsonURL = "mod/quiz/view-embedded.php?id=10578&username=$username";
	// echo $baseURL . $certHandsonURL;
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>jQuery UI Accordion - Default functionality</title>
<!--  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
-->
<link type="text/css" href="jquery-ui/css/redmond-light/jquery-ui-1.8.5.custom.css" rel="stylesheet" />
<script type="text/javascript" src="jquery-ui/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="jquery-ui/js/jquery-ui-1.8.4.custom.min.js"></script>
<script type='text/javascript' src='jquery-ui/dataTables/media/js/jquery.dataTables.min.js'></script>
<script type='text/javascript' src='jquery-ui/dataTables/examples/examples_support/jquery.jeditable.js'></script>
  <script>
  $(function() {
    $( "#accordion" ).accordion();
  });
  </script>
</head>
<body>
 
<div id="accordion">
  <h3>Kaseya Certified Administrator (KCA)</h3>
  <div>
    <p>
This certificate exam has 100 points. You must receive a score of <strong>90 or higher</strong> to pass the exam. The exam is comprised of two parts, <em>theory (30 points) </em>and <em>hands-on (70 points)</em>. 
<ul>
  <li>For the <a href="<?php echo $baseURL . $certTheoryURL; ?>">theory part</a>, you will receive 30 randomly selected multiple-choice or true-false questions that evaluate your familiarity with Kaseya VSA. You have 30 minutes to answer all of the questions. For this part, you have unlimited number of attempts. This means that you can retake the theory test over and over again until you get the perfect score, if desired. Your score will be provided to you immediately after taking the test. The score for this part comprises <strong>30%</strong> of your total score.</li>
  <li>For the <a href="<?php echo $baseURL . $certHandsonURL; ?>">hands-on part</a>, you will receive 18 randomly selected tasks that you would need to perform within two hours using a blank virtual environment. For this part, you have only three attempts. You can use up to two attempts for practice. Note that you must NOT submit your answer file for the practice attempts. Your answer file will be graded typically no longer than 10 business days (two weeks) from the time you took the test. The score for this part comprises<strong> 70% </strong>of your total score.</li>
</ul>
  </p>
  </div>
  <h3>Kaseya Certified Technician (KCT)</h3>
  <div>
    <p>
    Coming soon ...
    </p>
  </div>
</div>
 
 
</body>
</html>