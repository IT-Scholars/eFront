<html>
<body bgcolor='#DFEFFC'>
<center>
<p style='padding:120px 20px 20px 20px; width:50%;'>

<?php echo $_GET["message"]; ?>

<p>
</center>
</body>
</html>