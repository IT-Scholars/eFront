<?php
header('location:www/index.php');
?>